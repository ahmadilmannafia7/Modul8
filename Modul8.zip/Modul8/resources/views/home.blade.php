@extends('layouts.app')

@section('content')
    @include('default')
@endsection
